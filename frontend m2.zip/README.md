# Smart Event Management & Ticketing Platform
**WPR381 Group Project 2026 - Advanced Events (Pty) Ltd**

---

## Project Overview

This is our group project for WPR381. We built a full-stack web application for Advanced Events (Pty) Ltd that allows users to browse events, book tickets, and manage their bookings. Admins can create and manage events, view all bookings, and handle user enquiries.

The system is built with Node.js, Express, EJS templates and MongoDB.

---

## Technologies Used

- **Node.js** - backend runtime
- **Express.js** - routing and middleware
- **EJS** - server-side HTML templating
- **MongoDB** - database
- **Mongoose** - object modelling for MongoDB
- **bcrypt** - password hashing
- **express-session** - user sessions
- **connect-flash** - flash messages
- **dotenv** - environment variables
- **method-override** - allows PUT and DELETE in forms
- **nodemon** - auto-restarts server during development

---

## Team Members & Roles

| Member | Role |
|--------|------|
| Member 1 | Team Lead / Project Coordinator |
| Member 2 | Frontend Developer (UI/UX, EJS, CSS) |
| Member 3 | Backend Developer (routes, controllers) |
| Member 4 | Database Engineer (Mongoose schemas) |
| Member 5 | Security / DevOps (auth middleware, bcrypt, sessions) |

---

## My Contribution (Member 2 - Frontend)

I was responsible for designing and building all the frontend pages. This included:

- All EJS view templates (20 pages total)
- The full CSS stylesheet with a custom dark theme design system using CSS variables
- Client-side JavaScript for search filtering, modals, animations, form validation and the ticket quantity selector
- Making all pages responsive for mobile and desktop

**Pages I built:**
- Home page with hero section and featured events
- Events listing page with search and filter chips
- Event detail page with booking form and live price calculator
- Login and Register pages (split panel layout)
- User dashboard with booking stats
- My Bookings page with filter tabs
- Booking confirmation page
- Admin dashboard with analytics stats
- Admin event management table (CRUD)
- Create/Edit event form
- Admin bookings table
- Admin users table
- Admin enquiries table with modal viewer
- Contact page with FAQ accordion
- 404 and 500 error pages

---

## Setup Instructions

### Prerequisites
- Node.js v18 or higher
- MongoDB installed locally or a MongoDB Atlas account

### Steps

1. Clone the repo
```bash
git clone https://github.com/YOUR_GROUP/advevents.git
cd advevents
```

2. Install dependencies
```bash
npm install
```

3. Create a `.env` file in the root folder
```
PORT=3000
MONGO_URI=mongodb://localhost:27017/advevents
SESSION_SECRET=anysecretkeyhere
NODE_ENV=development
```

4. Run the app
```bash
npm run dev
```

5. Open your browser and go to `http://localhost:3000`

---

## Folder Structure

```
views/
 index.ejs # home page
 contact.ejs # contact form
 404.ejs
 500.ejs
 partials/
 header.ejs
 footer.ejs
 navbar.ejs
 flash.ejs
 auth/
 login.ejs
 register.ejs
 events/
 index.ejs # event listing
 detail.ejs # single event + booking
 user/
 dashboard.ejs
 bookings.ejs
 booking-confirmation.ejs
 admin/
 dashboard.ejs
 events.ejs
 event-form.ejs
 bookings.ejs
 users.ejs
 enquiries.ejs
 sidebar-admin.ejs

public/
 css/style.css
 js/main.js
```

---

## Notes

- All admin routes require the user to have `role: 'admin'` - this is enforced by middleware (Member 5's work)
- Forms use `method-override` so PUT and DELETE work through HTML forms
- The CSS uses custom properties (variables) throughout so colours and spacing are easy to update
- The design uses a dark theme with gold, teal and coral accents to give it a modern, professional look
