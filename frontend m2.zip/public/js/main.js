// navbar shrinks slightly on scroll
const navbar = document.querySelector('.navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  });
}

// mobile menu toggle
const hamburger = document.querySelector('.nav-hamburger');
const navLinks  = document.querySelector('.nav-links');
if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('mobile-open');
  });
}

// auto-dismiss flash messages after 4 seconds
document.querySelectorAll('.flash').forEach(flash => {
  setTimeout(() => {
    flash.style.opacity = '0';
    flash.style.transform = 'translateY(-8px)';
    flash.style.transition = 'all 0.4s ease';
    setTimeout(() => flash.remove(), 400);
  }, 4000);
});

// filter events by search input
function applyFilters() {
  const searchVal      = document.querySelector('#searchInput')?.value.toLowerCase() || '';
  const activeCategory = document.querySelector('.filter-chip[data-group="category"].active')?.dataset.filter || '';
  const activeAvail    = document.querySelector('.filter-chip[data-group="avail"].active')?.dataset.filter || '';

  document.querySelectorAll('.event-card-wrap').forEach(card => {
    const title    = card.dataset.title    || '';
    const category = card.dataset.category || '';
    const avail    = card.dataset.availability || '';

    const matchSearch = !searchVal      || title.includes(searchVal);
    const matchCat    = !activeCategory || category === activeCategory.toLowerCase();
    const matchAvail  = !activeAvail    || avail === activeAvail;

    card.style.display = (matchSearch && matchCat && matchAvail) ? '' : 'none';
  });

  const visible = document.querySelectorAll('.event-card-wrap:not([style*="display: none"])').length;
  const counter = document.querySelector('#resultsCount');
  if (counter) counter.textContent = `${visible} event${visible !== 1 ? 's' : ''}`;
}

const searchInput = document.querySelector('#searchInput');
if (searchInput) {
  searchInput.addEventListener('input', applyFilters);
}

// submit form when date sort changes
const dateFilter = document.querySelector('#dateFilter');
if (dateFilter) {
  dateFilter.addEventListener('change', () => {
    const form = dateFilter.closest('form');
    if (form) form.submit();
  });
}

// modal open/close
function openModal(id) {
  const overlay = document.getElementById(id);
  if (overlay) {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(id) {
  const overlay = document.getElementById(id);
  if (overlay) {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}

document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(o => closeModal(o.id));
  }
});

// confirm before delete/cancel actions
document.querySelectorAll('[data-confirm]').forEach(btn => {
  btn.addEventListener('click', e => {
    if (!confirm(btn.dataset.confirm)) e.preventDefault();
  });
});

// animate capacity bars on page load
document.querySelectorAll('.capacity-fill[data-fill]').forEach(bar => {
  const pct = parseFloat(bar.dataset.fill) || 0;
  setTimeout(() => {
    bar.style.width = Math.min(pct, 100) + '%';
    if (pct >= 90)      bar.style.background = 'var(--accent-coral)';
    else if (pct >= 70) bar.style.background = 'var(--accent-gold)';
  }, 200);
});

// show/hide password toggle
document.querySelectorAll('.password-toggle').forEach(toggle => {
  toggle.addEventListener('click', () => {
    const input = toggle.previousElementSibling;
    if (!input) return;
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    toggle.innerHTML = show
      ? `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
      : `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
  });
});

// basic required field validation before submit
document.querySelectorAll('form[data-validate]').forEach(form => {
  form.addEventListener('submit', e => {
    let valid = true;
    form.querySelectorAll('[required]').forEach(field => {
      if (!field.value.trim()) {
        valid = false;
        field.style.borderColor = 'var(--accent-coral)';
      } else {
        field.style.borderColor = '';
      }
    });
    if (!valid) e.preventDefault();
  });
});

// ticket quantity +/- buttons and live price update
const qtyInput       = document.querySelector('#ticketQty');
const qtyIncrease    = document.querySelector('#qtyIncrease');
const qtyDecrease    = document.querySelector('#qtyDecrease');
const totalPrice     = document.querySelector('#totalPrice');
const pricePerTicket = parseFloat(document.querySelector('#pricePerTicket')?.value || 0);

if (qtyInput) {
  const updateTotal = () => {
    const qty = parseInt(qtyInput.value) || 1;
    if (totalPrice) totalPrice.textContent = `R ${(qty * pricePerTicket).toFixed(2)}`;
  };

  if (qtyIncrease) {
    qtyIncrease.addEventListener('click', () => {
      const max = parseInt(qtyInput.max) || 10;
      if (parseInt(qtyInput.value) < max) {
        qtyInput.value = parseInt(qtyInput.value) + 1;
        updateTotal();
      }
    });
  }

  if (qtyDecrease) {
    qtyDecrease.addEventListener('click', () => {
      if (parseInt(qtyInput.value) > 1) {
        qtyInput.value = parseInt(qtyInput.value) - 1;
        updateTotal();
      }
    });
  }

  qtyInput.addEventListener('change', updateTotal);
  updateTotal();
}

// highlight active sidebar link based on current URL
const currentPath = window.location.pathname;
document.querySelectorAll('.sidebar-item').forEach(item => {
  if (item.getAttribute('href') === currentPath) {
    item.classList.add('active');
  }
});

// simple scroll reveal for cards
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});
